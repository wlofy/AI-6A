#include <mpi.h>
#include <stdio.h>

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    int data = rank;
    int tag = 123;
    MPI_Status status;
    if (rank == 0) {
        MPI_Send(&data, 1, MPI_INT, 1, tag, MPI_COMM_WORLD);
    } else if (rank == 1) {
        int recv_data;
        MPI_Recv(&recv_data, 1, MPI_INT, 0, tag, MPI_COMM_WORLD, &status);
        printf("Received data %d with tag %d\n", recv_data, status.MPI_TAG);
    }
    MPI_Finalize();
    return 0;
}
