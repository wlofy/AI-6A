#include <mpi.h>
#include <stdio.h>

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int data = 100;
    MPI_Status status;

    // Blocking communication timing
    MPI_Barrier(MPI_COMM_WORLD);
    double start_block = MPI_Wtime();

    if (rank == 0) {
        MPI_Send(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
        MPI_Recv(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, &status);
    } else if (rank == 1) {
        MPI_Recv(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status);
        MPI_Send(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double end_block = MPI_Wtime();

    if (rank == 0) {
        printf("Blocking communication time: %f seconds\n", end_block - start_block);
    }

    // Non-blocking communication timing
    MPI_Request send_req, recv_req;
    data = 200;

    MPI_Barrier(MPI_COMM_WORLD);
    double start_nonblock = MPI_Wtime();

    if (rank == 0) {
        MPI_Isend(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, &send_req);
        MPI_Irecv(&data, 1, MPI_INT, 1, 0, MPI_COMM_WORLD, &recv_req);
        MPI_Wait(&send_req, &status);
        MPI_Wait(&recv_req, &status);
    } else if (rank == 1) {
        MPI_Irecv(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &recv_req);
        MPI_Isend(&data, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &send_req);
        MPI_Wait(&recv_req, &status);
        MPI_Wait(&send_req, &status);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double end_nonblock = MPI_Wtime();

    if (rank == 0) {
        printf("Non-blocking communication time: %f seconds\n", end_nonblock - start_nonblock);
    }

    MPI_Finalize();
    return 0;
}
