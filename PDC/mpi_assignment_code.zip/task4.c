#include <mpi.h>
#include <stdio.h>

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
    int data = rank;
    int next = (rank + 1) % size;
    int prev = (rank - 1 + size) % size;
    int recv_data;
    MPI_Status status;

    MPI_Sendrecv(&data, 1, MPI_INT, next, 0, &recv_data, 1, MPI_INT, prev, 0, MPI_COMM_WORLD, &status);
    printf("Process %d received %d from process %d\n", rank, recv_data, prev);

    MPI_Finalize();
    return 0;
}
